package finalAlgorithm;

import java.util.Scanner;

public class Algo17_TaskProfit 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enetr number of taskes");
		int tasks = sc.nextInt();
		
		for(int i= 0;i<tasks;i++)
		{
			
		}
	}
}
